/** @param {NS} ns */
export async function main(ns) {

  ns.tprint('Ram Upgrade: ' + ns.getPurchasedServerUpgradeCost('server-0',ns.getServerMaxRam('server-0') * 2));

}